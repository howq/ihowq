<div>
    关于我们
</div>

<script>
    $("#news-right").hide();
  //  document.getElementById('news-right').style.display="";
</script>
