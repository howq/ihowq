<div id="header" class="col-sm-12"><b>后台管理系统</b></div>
<div id="nav-header" class="col-sm-12">
    <ol class="breadcrumb">
        <li><a href="#">首页</a></li>
        <li><a href="#">管理目录</a></li>
    </ol>
</div>