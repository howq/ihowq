<form class="mt30" role="form" method="POST" action="admin.php?r=site/cookie" style="width: 15vw">
     <div class="form-group">
         <label class="control-label" for="password">密码</label>
         <input type="password" placeholder="请输入密码确认上传权限" required="" name="password" class="form-control">
     </div>

     <div class="form-group clearfix">
         <button class="btn btn-primary pl20 pr20 pull-right" type="submit" id="isOk">确定</button>
     </div>
</form>

